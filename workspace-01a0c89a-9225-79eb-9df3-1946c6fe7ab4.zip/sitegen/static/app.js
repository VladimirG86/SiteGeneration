/* СБОРКА: логика мастера создания сайта (vanilla JS, без зависимостей) */
'use strict';

const $ = (s, r = document) => r.querySelector(s);

/* ---------------------------------------------------------------- state -- */
const LS_KEY = 'sborka_state_v1';
const state = {
  step: -1, // -1 = welcome
  answers: { name: '', about: '', products: '', advantages: '', extras: '' },
  theme: { mode: 'light', accent: 'purple' },
  email: '',
  agree1: false, agree2: false,
  chips: null,          // {products:[], advantages:[], extras:[]}
  chipsLoading: false,
  visited: 0,
  job: null,
  code: '',
  editorJob: null,
  editorVersion: 0,
  editorBusy: false,
};
let CFG = { llm: false, accents: [] };

function saveState() {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify({
      answers: state.answers, theme: state.theme, email: state.email,
      agree1: state.agree1, agree2: state.agree2, chips: state.chips,
    }));
  } catch (e) { /* private mode — ок */ }
}
function restoreState() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return;
    const d = JSON.parse(raw);
    Object.assign(state.answers, d.answers || {});
    Object.assign(state.theme, d.theme || {});
    state.email = d.email || '';
    state.agree1 = !!d.agree1; state.agree2 = !!d.agree2;
    state.chips = d.chips || null;
  } catch (e) { /* ignore */ }
}

/* ---------------------------------------------------------------- icons -- */
const I = {
  next: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" width="18" height="18"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" width="14" height="14"><path d="M4 12.5l5 5L20 7"/></svg>',
  spinner: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" width="14" height="14"><path d="M21 12a9 9 0 1 1-5-8"/></svg>',
  help: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" width="15" height="15"><circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 1 1 3.6 2.24c-.7.33-1.1.9-1.1 1.66v.6"/><circle cx="12" cy="17" r=".4" fill="currentColor"/></svg>',
  briefcase: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" width="20" height="20"><rect x="3" y="7" width="18" height="13" rx="2.5"/><path d="M9 7V5.5A1.5 1.5 0 0 1 10.5 4h3A1.5 1.5 0 0 1 15 5.5V7"/><path d="M3 12h18"/></svg>',
  box: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" width="20" height="20"><path d="M12 2l8 4.5v9L12 20l-8-4.5v-9L12 2z"/><path d="M4 6.5l8 4.5 8-4.5M12 11v9"/></svg>',
  award: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" width="20" height="20"><circle cx="12" cy="9" r="5"/><path d="M8.5 13.5L7 21l5-2.5L17 21l-1.5-7.5"/></svg>',
  palette: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" width="20" height="20"><circle cx="12" cy="12" r="9"/><circle cx="8.5" cy="10" r="1" fill="currentColor"/><circle cx="12" cy="7.5" r="1" fill="currentColor"/><circle cx="15.5" cy="10" r="1" fill="currentColor"/><path d="M12 21a9 9 0 0 0 6.5-2.8c.8-.9.2-2.2-1-2.2H12a3 3 0 0 1 0-6h5.4c1.2 0 2-1.2 1.4-2.3"/></svg>',
  chat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" width="20" height="20"><path d="M21 12a8 8 0 0 1-8 8H4l2-3a8 8 0 1 1 15-5z"/></svg>',
  spark: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" width="20" height="20"><path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3z"/><path d="M18.5 15.5l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7.7-2z"/></svg>',
};

/* ---------------------------------------------------------------- steps -- */
const STEP_DEFS = [
  {
    id: 'about', label: 'О бизнесе', title: 'Расскажите о своём бизнесе', icon: 'briefcase',
    sub: 'Как называется компания, чем занимаетесь и для кого. Двух-трёх предложений хватит — ИИ разберётся в деталях.',
    help: {
      title: 'Как описать бизнес',
      text: 'Просто объясните, чем занимаетесь и для кого — как рассказали бы знакомому.',
      good: ['Чем занимаетесь и в каком городе', 'Кто ваши клиенты', 'Сколько лет на рынке'],
      bad: ['Общих красивых фраз вроде «высокое качество» и «индивидуальный подход»', 'Длинной истории компании'],
      example: '«Ремонтируем квартиры в Казани с 2015 года. Бригада из 6 мастеров, работаем по договору. Делаем косметический и капитальный ремонт, кухни и санузлы под ключ. Клиенты — владельцы квартир в новостройках и вторичке, фиксируем сроки в смете.»',
    },
  },
  {
    id: 'products', label: 'Продукт', title: 'Что вы продаёте', icon: 'box',
    sub: 'Основные услуги или товары — каждую позицию с новой строки. Цена точная, диапазоном или «по запросу» — как удобно.',
    required: true,
    help: {
      title: 'Как перечислить услуги',
      text: 'Каждую услугу или товар — с новой строки. Пишите так, как их называете клиентам.',
      good: ['3–8 основных позиций', 'Цену рядом с позицией, если хотите', 'Формулировки из вашей практики'],
      bad: ['Списка из 30 позиций — возьмите главные', 'Аббревиатур без расшифровки'],
      example: '«Диагностика двигателя — от 1500 ₽\nЗамена масла и фильтров — 2500 ₽\nРемонт ходовой — по запросу»',
    },
  },
  {
    id: 'advantages', label: 'Отличия', title: 'Чем вы отличаетесь от конкурентов', icon: 'award',
    sub: 'То, ради чего клиенты выбирают именно вас. ИИ вынесет это в главные заголовки. Можно пропустить, но именно это убеждает посетителей.',
    help: {
      title: 'Как описать отличия',
      text: 'Факты и цифры работают лучше прилагательных: гарантия, сроки, опыт, условия.',
      good: ['Гарантия и её срок', 'Скорость ответа или выезда', 'Опыт, сертификаты, количество клиентов'],
      bad: ['«Лучшие на рынке» без фактов', 'Полного копирования текстов конкурентов'],
      example: '«Гарантия 3 года, выезд в день обращения, перезваниваем за 5 минут»',
    },
  },
  {
    id: 'theme', label: 'Тема', title: 'Тема оформления сайта', icon: 'palette',
    sub: 'В каком стиле показать сайт посетителям. Не переживайте: тему и цвета можно поменять в любой момент после создания.',
  },
  {
    id: 'extras', label: 'Пожелания', title: 'Хотите рассказать что-то ещё?', icon: 'chat',
    sub: 'Всё, что мы могли упустить: вопросы от клиентов, пожелания по оформлению, личная история, спецпредложения, сертификаты, ограничения. Спокойно пропускайте, если нечего добавить.',
    help: {
      title: 'Что сюда писать',
      text: 'Любой контекст, который поможет ИИ сделать сайт точнее.',
      good: ['Спецпредложения и акции', 'Особенности работы (часы, районы, выезд)', 'Пожелания по стилю или структуре'],
      bad: ['Перечня услуг заново — он уже есть на шаге 2', 'Личных данных клиентов'],
      example: '«Скидка 10% на первое обслуживание. Работаем с 9 до 21 без выходных, выезжаем по области. Хотим тёмный акцент и блок с фото работ.»',
    },
  },
  {
    id: 'review', label: 'Проверка', title: 'Почти готово', icon: 'spark',
    sub: 'Мы учли ваши ответы — дальше ИИ соберёт сайт. Хотите что-то поправить — нажмите «Назад» или кнопку у пункта.',
  },
];

/* ----------------------------------------------------------------- init -- */
document.addEventListener('DOMContentLoaded', () => {
  restoreState();
  bindButtons();
  fetchConfig();
  showScreen('welcome');
});

async function fetchConfig() {
  try {
    const r = await fetch('/api/config');
    CFG = await r.json();
  } catch (e) { CFG = { llm: false, accents: [] }; }
  const note = $('#mode-note');
  if (note) {
    note.textContent = CFG.llm
      ? `Режим LLM: сайт генерирует модель ${CFG.model} через RouterAI.`
      : 'Демо-режим: сайт собирает встроенный генератор. Добавьте ключ RouterAI (ROUTERAI_API_KEY) — и генерировать будет LLM.';
  }
  if (!CFG.accents || !CFG.accents.length) {
    CFG.accents = [
      { id: 'purple', label: 'Фиолетовый', hex: '#7c3aed' }, { id: 'blue', label: 'Синий', hex: '#2563eb' },
      { id: 'emerald', label: 'Изумруд', hex: '#059669' }, { id: 'orange', label: 'Оранжевый', hex: '#ea580c' },
      { id: 'rose', label: 'Малиновый', hex: '#e11d48' }, { id: 'teal', label: 'Бирюзовый', hex: '#0d9488' }];
  }
}

function bindButtons() {
  $('#btn-start').addEventListener('click', () => goStep(0));
  $('#btn-back').addEventListener('click', () => goStep(Math.max(0, state.step - 1)));
  $('#btn-next').addEventListener('click', nextStep);
  $('#modal-close').addEventListener('click', closeModal);
  $('#modal-ok').addEventListener('click', closeModal);
  $('#modal').addEventListener('click', (e) => { if (e.target === $('#modal')) closeModal(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

  /* code screen */
  $('#code-input').addEventListener('input', (e) => {
    e.target.value = e.target.value.replace(/\D/g, '').slice(0, 6);
    $('#btn-create').disabled = e.target.value.length !== 6;
  });
  $('#btn-create').addEventListener('click', startGeneration);
  $('#btn-resend').addEventListener('click', startResend);
  $('#btn-change-email').addEventListener('click', () => { showScreen('wizard'); goStep(5); });

  /* result */
  $('#btn-editor').addEventListener('click', () => openEditor(state.editorJob));
  $('#btn-restart').addEventListener('click', resetAll);

  /* editor */
  $('#ed-back').addEventListener('click', () => showScreen('result'));
  $('#ed-refresh').addEventListener('click', () => refreshEditor());
  $('#ed-undo').addEventListener('click', editorUndo);
  $('#ed-device').addEventListener('click', toggleDevice);
  $('#ed-send').addEventListener('click', sendChat);
  $('#ed-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendChat(); }
  });
}

/* ------------------------------------------------------------ screens ---- */
function showScreen(name) {
  ['welcome', 'wizard', 'code', 'generating', 'result'].forEach((n) => {
    $('#screen-' + n).classList.toggle('hidden', n !== name);
  });
}

function goHome() {
  showScreen('welcome');
  state.step = -1;
  return false;
}

/* ------------------------------------------------------------ stepper ---- */
function renderStepper() {
  const c = $('#stepper');
  c.innerHTML = '';
  STEP_DEFS.forEach((d, i) => {
    const st = document.createElement('div');
    const done = i < state.step, current = i === state.step;
    st.className = 'st' + (done ? ' done' : '') + (current ? ' current' : '') + (i <= state.visited && !current ? ' clickable' : '');
    st.innerHTML = `<span class="dot">${done ? I.check : i + 1}</span><span class="lbl">${d.label}</span>`;
    if (i <= state.visited && !current) st.addEventListener('click', () => goStep(i));
    c.appendChild(st);
  });
}

/* --------------------------------------------------------------- steps --- */
function goStep(i) {
  state.step = i;
  state.visited = Math.max(state.visited, i);
  showScreen('wizard');
  renderStepper();
  renderStep();
  const back = $('#btn-back');
  back.classList.toggle('hidden', i === 0);
  const next = $('#btn-next');
  next.innerHTML = (i === STEP_DEFS.length - 1 ? 'Получить код ' : 'Далее ') + I.next;
  validateStep();
}

function renderStep() {
  const def = STEP_DEFS[state.step];
  const body = $('#step-body');
  body.innerHTML = '';

  const head = document.createElement('div');
  head.className = 'step-head';
  head.innerHTML = `
    <div class="step-icon">${I[def.icon]}</div>
    <h2>${def.title}</h2>
    ${def.help ? `<button class="help-link">${I.help} Что написать?</button>` : ''}`;
  body.appendChild(head);
  if (def.help) head.querySelector('.help-link').addEventListener('click', () => openModal(def.help));
  if (def.sub) {
    const p = document.createElement('p');
    p.className = 'step-sub';
    p.textContent = def.sub;
    body.appendChild(p);
  }

  const a = state.answers;
  if (def.id === 'about') {
    body.appendChild(field('Название компании', 'name', 'text', 'Например, кофейня «Brewhaus»', true));
    body.appendChild(field('О бизнеса', 'about', 'textarea', 'Например: кофейня в центре Москвы. Работаем с 2019 года, своя обжарка, завтраки и кофе с собой.', true, 4));
    autoFocus();
  }

  if (def.id === 'products' || def.id === 'advantages' || def.id === 'extras') {
    const key = def.id === 'products' ? 'products' : def.id === 'advantages' ? 'advantages' : 'extras';
    const label = def.id === 'products' ? 'Услуги или товары' : def.id === 'advantages' ? 'Ваши преимущества' : 'Дополнительно';
    body.appendChild(field(label, key, 'textarea', def.id === 'products' ? 'Перечислите услуги или товары — каждый с новой строки' : '', def.required, def.id === 'products' ? 6 : 4));
    renderChips(body, key);
    autoFocus();
  }

  if (def.id === 'theme') renderTheme(body);

  if (def.id === 'review') renderReview(body);
}

function field(label, key, tag, placeholder, required, rows) {
  const w = document.createElement('div');
  w.className = 'field';
  w.innerHTML = `
    <label>${label} ${required ? '<span class="req">*</span>' : '<span style="color:#9aa2b8;font-weight:500">(необязательно)</span>'}</label>
    ${tag === 'textarea'
      ? `<textarea rows="${rows || 4}" data-key="${key}" placeholder="${placeholder || ''}"></textarea>`
      : `<input type="text" data-key="${key}" placeholder="${placeholder || ''}">`}
    <div class="err">Заполните поле — хотя бы пара слов</div>`;
  const el = w.querySelector('input,textarea');
  el.value = state.answers[key] || '';
  el.addEventListener('input', () => {
    state.answers[key] = el.value;
    saveState(); validateStep();
  });
  return w;
}

function autoFocus() {
  setTimeout(() => {
    const f = $('#step-body input, #step-body textarea');
    if (f && window.innerWidth > 720) f.focus();
  }, 60);
}

function renderChips(container, key) {
  const wrap = document.createElement('div');
  const list = state.chips && state.chips[key];
  if (!list) {
    wrap.className = 'chips loading';
    wrap.innerHTML = '<span class="chip-skel"></span><span class="chip-skel" style="width:120px"></span><span class="chip-skel" style="width:180px"></span>';
    container.appendChild(wrap);
    ensureChips().then(() => { if (document.body.contains(wrap)) renderChipsRefresh(container, key, wrap); });
    return;
  }
  renderChipsList(wrap, list, key);
  container.appendChild(wrap);
}
function renderChipsRefresh(container, key, oldWrap) {
  const wrap = document.createElement('div');
  renderChipsList(wrap, state.chips[key] || [], key);
  container.replaceChild(wrap, oldWrap);
}
function renderChipsList(wrap, list, key) {
  wrap.className = 'chips';
  const lbl = document.createElement('div');
  lbl.className = 'chips-label';
  lbl.innerHTML = 'Нажмите — <b>добавим</b>, а вы поправьте под себя:';
  wrap.appendChild(lbl);
  const row = document.createElement('div');
  row.className = 'chips';
  (list || []).slice(0, 9).forEach((text) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'chip';
    b.textContent = text;
    const used = () => state.answers[key].toLowerCase().includes(text.toLowerCase());
    b.classList.toggle('used', used());
    b.addEventListener('click', () => {
      const ta = $(`#step-body textarea[data-key="${key}"]`);
      if (!ta) return;
      if (used()) return;
      ta.value = (ta.value.trim() ? ta.value.replace(/\s*$/, '\n') : '') + text;
      state.answers[key] = ta.value;
      b.classList.add('used');
      saveState(); validateStep();
      ta.focus();
    });
    row.appendChild(b);
  });
  wrap.appendChild(row);
}

async function ensureChips() {
  if (state.chips || state.chipsLoading) return;
  state.chipsLoading = true;
  try {
    const r = await fetch('/api/analyze', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: state.answers.name, about: state.answers.about }),
    });
    const data = await r.json();
    state.chips = data.chips;
  } catch (e) {
    state.chips = { products: [], advantages: [], extras: [] };
  }
  state.chipsLoading = false;
  saveState();
}

function renderTheme(container) {
  const w = document.createElement('div');
  w.innerHTML = `
    <div class="theme-grid">
      <button type="button" class="theme-card" data-mode="light">
        <div class="theme-prev light"><div class="bar"></div><div class="bar s2"></div><div class="bar s3"></div><div class="btn"></div></div>
        <div class="theme-name">Светлая</div>
      </button>
      <button type="button" class="theme-card" data-mode="dark">
        <div class="theme-prev dark"><div class="bar"></div><div class="bar s2"></div><div class="bar s3"></div><div class="btn"></div></div>
        <div class="theme-name">Тёмная</div>
      </button>
    </div>
    <div class="accent-row"><span class="lbl">Акцентный цвет</span></div>`;
  const modeBtns = w.querySelectorAll('.theme-card');
  modeBtns.forEach((b) => {
    b.classList.toggle('sel', b.dataset.mode === state.theme.mode);
    b.addEventListener('click', () => {
      state.theme.mode = b.dataset.mode;
      modeBtns.forEach((x) => x.classList.toggle('sel', x === b));
      saveState();
    });
  });
  const row = w.querySelector('.accent-row');
  (CFG.accents || []).forEach((acc) => {
    const s = document.createElement('button');
    s.type = 'button';
    s.className = 'swatch' + (acc.id === state.theme.accent ? ' sel' : '');
    s.style.background = acc.hex;
    s.title = acc.label;
    s.addEventListener('click', () => {
      state.theme.accent = acc.id;
      row.querySelectorAll('.swatch').forEach((x) => x.classList.remove('sel'));
      s.classList.add('sel');
      saveState();
    });
    row.appendChild(s);
  });
  container.appendChild(w);
}

function renderReview(container) {
  const rows = [
    ['О бизнесе', state.answers.name + (state.answers.name && state.answers.about ? '. ' : '') + state.answers.about, 0],
    ['Продукт', state.answers.products, 1],
    ['Отличия', state.answers.advantages || '—', 2],
    ['Тема', (state.theme.mode === 'dark' ? 'Тёмная' : 'Светлая') + ', акцент: ' + accentLabel(state.theme.accent), 3],
    ['Пожелания', state.answers.extras || '—', 4],
  ];
  const w = document.createElement('div');
  const sum = document.createElement('div');
  sum.className = 'summary';
  rows.forEach(([k, v, stepIdx]) => {
    const r = document.createElement('div');
    r.className = 'sum-row';
    r.innerHTML = `<span class="k">${k}</span><span class="v">${escapeHtml(truncate(v, 260))}</span>
      <button class="edit" type="button">изменить</button>`;
    r.querySelector('.edit').addEventListener('click', () => goStep(stepIdx));
    sum.appendChild(r);
  });
  w.appendChild(sum);

  const emailField = document.createElement('div');
  emailField.className = 'field';
  emailField.innerHTML = `
    <label>Куда сохранить доступ?</label>
    <input type="email" data-key="email" placeholder="you@example.com">
    <div class="err">Похоже, в адресе почты ошибка</div>`;
  const em = emailField.querySelector('input');
  em.value = state.email || '';
  em.addEventListener('input', () => { state.email = em.value; saveState(); validateStep(); });
  w.appendChild(emailField);

  const note = document.createElement('p');
  note.className = 'sub';
  note.style.cssText = 'font-size:13.5px;margin:-8px 0 18px';
  note.textContent = 'На эту почту придут ссылка на сайт, чеки и важные уведомления. Пароль не нужен — вход по коду.';
  w.appendChild(note);

  [['agree1', 'Я принимаю <a href="#" onclick="return false">оферту</a> и <a href="#" onclick="return false">политику конфиденциальности</a>', true],
   ['agree2', 'Я согласен получать информацию о новых функциях, акциях и обучающих материалах (можно отписаться в любое время)', false],
  ].forEach(([key, html, req]) => {
    const l = document.createElement('label');
    l.className = 'check-line';
    l.innerHTML = `<input type="checkbox" data-check="${key}"> <span>${html}${req ? ' <b style="color:#e11d48">*</b>' : ''}</span>`;
    const cb = l.querySelector('input');
    cb.checked = state[key];
    cb.addEventListener('change', () => { state[key] = cb.checked; saveState(); validateStep(); });
    w.appendChild(l);
  });

  container.appendChild(w);
}

function accentLabel(id) {
  const a = (CFG.accents || []).find((x) => x.id === id);
  return a ? a.label.toLowerCase() : id;
}

/* ------------------------------------------------------------ validate --- */
function validateStep() {
  const def = STEP_DEFS[state.step];
  const next = $('#btn-next');
  let ok = true;
  if (def.id === 'about') {
    ok = state.answers.name.trim().length >= 1 && state.answers.about.trim().length >= 10;
    markField('name', state.answers.name.trim().length >= 1);
    markField('about', state.answers.about.trim().length >= 10);
  } else if (def.id === 'products') {
    ok = state.answers.products.trim().length >= 3;
    markField('products', ok);
  } else if (def.id === 'review') {
    const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(state.email.trim());
    ok = emailOk && state.agree1;
    markField('email', emailOk || !state.email);
  }
  next.disabled = !ok;
  return ok;
}
function markField(key, valid) {
  const el = $(`#step-body [data-key="${key}"]`);
  if (el) el.closest('.field').classList.toggle('invalid', !valid);
}

function nextStep() {
  if (!validateStep()) return;
  if (state.step === 4) { goStep(5); return; }
  if (state.step === 5) { openCodeScreen(); return; }
  goStep(state.step + 1);
}

/* --------------------------------------------------------------- modal --- */
function openModal(help) {
  $('#modal-title').textContent = help.title;
  $('#modal-text').textContent = help.text;
  $('#modal-good').innerHTML = help.good.map((x) => `<li>${x}</li>`).join('');
  $('#modal-bad').innerHTML = help.bad.map((x) => `<li>${x}</li>`).join('');
  $('#modal-example').textContent = help.example;
  $('#modal').classList.remove('hidden');
}
function closeModal() { $('#modal').classList.add('hidden'); }

/* ----------------------------------------------------------- code step --- */
function openCodeScreen() {
  state.code = String(Math.floor(100000 + Math.random() * 900000));
  $('#code-email-text').innerHTML = `Мы «отправили» 6-значный код на <b>${escapeHtml(state.email)}</b>. После подтверждения сразу начнём создавать сайт.`;
  $('#demo-code').textContent = state.code;
  const inp = $('#code-input');
  inp.value = '';
  $('#btn-create').disabled = true;
  showScreen('code');
  setTimeout(() => inp.focus(), 80);
  startResend(true);
}
let resendTimer = null;
function startResend(init) {
  let sec = 44;
  const btn = $('#btn-resend'), txt = $('#resend-text');
  clearInterval(resendTimer);
  btn.disabled = true;
  const tick = () => {
    txt.textContent = sec > 0 ? `Отправить ещё раз (${sec})` : 'Отправить ещё раз';
    if (sec <= 0) { btn.disabled = false; clearInterval(resendTimer); }
    sec--;
  };
  tick(); resendTimer = setInterval(tick, 1000);
  if (init) $('#demo-code').textContent = state.code;
}

/* ----------------------------------------------------------- generate ---- */
async function startGeneration() {
  if ($('#code-input').value !== state.code) { $('#code-input').value = ''; $('#btn-create').disabled = true; return; }
  showScreen('generating');
  $('#gen-error').classList.add('hidden');
  $('#gen-warning').classList.add('hidden');
  $('#gen-sub').textContent = CFG.llm
    ? `Модель ${CFG.model} анализирует ответы, проектирует структуру и пишет тексты. Обычно 1–3 минуты.`
    : 'ИИ анализирует ваши ответы, проектирует структуру и пишет тексты. Демо-режим: меньше минуты.';

  const stages = ['Анализируем ваш бизнес', 'Проектируем структуру', 'Пишем тексты', 'Верстаем страницу', 'Рисуем изображения'];
  const hints = ['Определяем нишу и аудиторию', 'Подбираем секции и порядок блоков', 'Заголовки, выгоды, возражения', 'Собираем секции в страницу', 'Графика и оформление темы'];
  const ul = $('#stage-list');
  ul.innerHTML = stages.map((s) => `<li><span class="st-dot"></span><span>${s}<small class="st-hint"></small></span></li>`).join('');

  let jobId;
  try {
    const r = await fetch('/api/generate', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: state.answers.name, about: state.answers.about,
        products: state.answers.products, advantages: state.answers.advantages,
        extras: state.answers.extras, theme_mode: state.theme.mode,
        accent: state.theme.accent, email: state.email,
      }),
    });
    jobId = (await r.json()).job_id;
  } catch (e) {
    genError('Не удалось запустить генерацию. Проверьте, что сервер работает.');
    return;
  }

  const started = Date.now();
  const poll = setInterval(async () => {
    let job;
    try {
      job = await (await fetch('/api/job/' + jobId)).json();
    } catch (e) { return; }
    const items = ul.querySelectorAll('li');
    items.forEach((li, i) => {
      li.classList.toggle('done', i < job.stage || job.status === 'done');
      li.classList.toggle('current', i === job.stage && job.status === 'running');
      li.querySelector('.st-dot').innerHTML = (i < job.stage || job.status === 'done') ? I.check
        : (i === job.stage && job.status === 'running') ? I.spinner : '';
      const hint = li.querySelector('.st-hint');
      if (hint) hint.textContent = i === job.stage ? hints[i] : '';
    });
    const p = job.status === 'done' ? 100 : Math.min(96, (job.stage / 5) * 100 + 4);
    $('#progress-fill').style.width = p + '%';

    if (job.status === 'done') {
      clearInterval(poll);
      if (job.warning) { $('#gen-warning').textContent = job.warning; $('#gen-warning').classList.remove('hidden'); }
      setTimeout(() => showResult(jobId, started), job.warning ? 1400 : 500);
    } else if (job.status === 'error') {
      clearInterval(poll);
      genError('Ошибка генерации: ' + (job.error || 'неизвестная'));
    }
  }, 700);
}

function genError(msg) {
  const el = $('#gen-error');
  el.textContent = msg;
  el.classList.remove('hidden');
  const again = document.createElement('button');
  again.className = 'btn-grad';
  again.style.marginTop = '16px';
  again.textContent = 'Попробовать снова';
  again.addEventListener('click', () => startGeneration());
  el.appendChild(document.createElement('br'));
  el.appendChild(again);
}

/* ------------------------------------------------------------- result ---- */
function showResult(jobId, started) {
  const secs = Math.max(1, Math.round((Date.now() - started) / 1000));
  $('#result-sub').textContent = `Сайт собран за ${secs} c. Дальше — интереснее: откройте редактор и скажите ИИ, что изменить (например, «сделай интернет-магазин»).`;
  const url = '/api/site/' + jobId;
  const frame = $('#site-frame');
  frame.src = url;
  frame.addEventListener('load', () => fitFrame());
  $('#btn-open-site').href = url;
  $('#btn-download').href = url;
  $('#btn-download').setAttribute('download', 'site-' + jobId + '.html');
  state.editorJob = jobId;
  state.editorVersion = 0;
  showScreen('result');
  setTimeout(fitFrame, 100);
}
function fitFrame() {
  const frame = $('#site-frame');
  const box = frame.parentElement;
  if (!box.clientWidth) return;
  const scale = box.clientWidth / 1280;
  frame.style.transform = `scale(${scale})`;
  frame.style.height = Math.round(720 / scale) + 'px';
  frame.parentElement.style.height = Math.min(640, Math.round(720 * scale)) + 'px';
}
window.addEventListener('resize', fitFrame);

/* -------------------------------------------------------------- utils ---- */
function resetAll() {
  state.step = -1; state.visited = 0; state.job = null;
  state.answers = { name: '', about: '', products: '', advantages: '', extras: '' };
  state.chips = null; state.email = ''; state.agree1 = false; state.agree2 = false;
  saveState();
  showScreen('welcome');
  fetchConfig();
}
function truncate(s, n) { s = s || ''; return s.length > n ? s.slice(0, n - 1) + '…' : s; }
function escapeHtml(s) {
  return String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/* Ctrl+Enter — следующий шаг */
document.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
    const b = $('#btn-next');
    if (b && !$('#screen-wizard').classList.contains('hidden') && !b.disabled) b.click();
  }
});
